import React from 'react'

export default function Create() {
  return (
    <div>
      Create page
    </div>
  )
}
